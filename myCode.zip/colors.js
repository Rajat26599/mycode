const colors = {
    primary: '#1972B4',
    button: '#78C339',
    lightBlueBg: '#e0f7ff',
}

export default colors;