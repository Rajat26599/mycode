import {Text} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome'

const BillerScreen = () => {

    return <>
    <FontAwesome name='home' size={20} color="black" />
    <Text style={{color: 'green', fontSize: 26}}>Biller Screen</Text>
    </>
}


export default BillerScreen;

